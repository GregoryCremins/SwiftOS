//
//  MemoryArray.swift
//  XCodeOS3
//
//  Created by Marist User on 5/9/16.
//  Copyright © 2016 Marist User. All rights reserved.
//

import Foundation

import Cocoa
class MemoryArray : NSObject, NSTableViewDataSource
{

    
}