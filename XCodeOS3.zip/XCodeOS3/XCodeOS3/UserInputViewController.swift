//
//  UserInputViewController.swift
//  XCodeOS3
//
//  Created by Marist User on 5/7/16.
//  Copyright © 2016 Marist User. All rights reserved.
//

import Foundation
import Cocoa

class UserInputViewController : NSTextField{
    
    override func keyDown(theEvent: NSEvent) {
        //if (theEvent.keyCode == 1){
        //print("test")
        //        }
        
    }
    
}